Please fill out the below template as best you can.
--------------------------------------------------------

### Description of the Issue
Describe the issue as best you can. I love screenshots and greatly appreciate the use of CodePen, JSFiddle, or similar demos.

### System Configuration
#### Version of reveal-leap-motion

#### Browser and Version

### Steps to Reproduce the Issue
1. Step 1
1. Step 2
